﻿using System;
using System.Collections.Generic;
using System.Linq;
using static System.Console;
using System.Text;
using System.Threading.Tasks;

namespace Day3PracticeFeaturesInCsharp
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("Hello ChangePond Technologies");
        }
    }
}
