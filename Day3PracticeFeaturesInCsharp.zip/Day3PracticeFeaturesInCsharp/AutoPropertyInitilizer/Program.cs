﻿using System;
using System.Collections.Generic;
using System.Linq;
using static System.Console;
using System.Text;
using System.Threading.Tasks;

namespace AutoPropertyInitilizer
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee employee = new Employee();

            employee.EmployeeId = 2147;
            employee.EmployeeName = "Aravind";
          //  employee.Salary = 78965;

            WriteLine(employee.EmployeeId);
            WriteLine(employee.EmployeeName);
            WriteLine(employee.Salary);

            Console.ReadLine();
        }
    }
}
