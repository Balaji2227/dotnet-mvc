﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using static System.Console;
using System.Text;
using System.Threading.Tasks;

namespace DictionaryInitilizer
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> dictionary = new Dictionary<string, string>()
            {
                ["Aravind"] ="Aravind",
                ["Aamir"] ="Aamir",
                ["Dharman"] ="Dharman",
                ["Barani"] ="Barani",
                ["Harish"] ="Harish",
            };

           dictionary ["Aravind"]="Ashok";
            dictionary["Ashok"] = "Ashok";

            foreach (var content in dictionary)
            {
                WriteLine(content.Key + "   " + content.Value);
            }

            Console.ReadLine();


        }
    }
}
