﻿using System;
using System.Collections.Generic;
using System.Linq;
using static System.Console;
using System.Text;
using System.Threading.Tasks;

namespace NameofExpression
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee employee = new Employee();

            WriteLine(nameof(employee.EmployeeId));
            WriteLine(nameof(employee.EmployeeName));
            WriteLine(nameof(employee.Salary));

            ReadLine();

        }
    }
}
