﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NameofExpression
{
    public class Employee
    {
        public int EmployeeId { get; set; } = 3377;

        public string EmployeeName { get; set; } = "Aamir Sherif";

        public int Salary { get; } = 22300;
    }
}
