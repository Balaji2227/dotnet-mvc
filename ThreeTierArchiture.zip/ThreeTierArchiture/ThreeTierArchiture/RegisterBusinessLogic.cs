﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;

namespace sample1
{

    public interface Iregister
    {
        void employee_details(string username, int mobile, string usermail, string userpassword);
    }

    public class register_DAL : Iregister
    {


        public void employee_details(string username, int mobile, string useremail, string userpassword)
        {
            try
            {

                string connStr = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;

                using (SqlConnection Con = new SqlConnection(connStr))
                {
                    String query = "INSERT INTO employeedetails2 (name,mobile,email,password) VALUES (@txtName,@txtMobile,@txtEmail,@txtpassword)";
                    using (SqlCommand cmd = new SqlCommand(query, Con))
                    {
                        Con.Open();
                        cmd.Parameters.AddWithValue("@txtName", username);
                        cmd.Parameters.AddWithValue("@txtMobile", mobile);
                        cmd.Parameters.AddWithValue("@txtEmail", useremail);
                        cmd.Parameters.AddWithValue("@txtpassword", userpassword);
                        cmd.ExecuteNonQuery();
                        Con.Close();
                    }

                    // Nomal insert method=======> SqlCommand cmd = new SqlCommand("insert into employeedetails2 values('" + username + "','" + mobile + "','" + useremail + "')", Con);
                }

            }
            catch (Exception exc)
            {
                Console.Write(exc);
            }






        }
    }
}