﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using AuthorizeController.Models;
using AuthorizeController.Infrastructure;

namespace AuthorizeController.Controllers
{
    [CustomAuthenticationFilter]
    [Authorize(Roles="Manager")]
    public class MasterController : Controller
    {
        private Aravind_traineeEntities db = new Aravind_traineeEntities();

        // GET: /Master/
        public ActionResult Index()
        {
            var tbl_master = db.tbl_master.Include(t => t.tbl_login);
            return View(tbl_master.ToList());
        }
         [Authorize(Roles = "Manager")]
        // GET: /Master/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_master tbl_master = db.tbl_master.Find(id);
            if (tbl_master == null)
            {
                return HttpNotFound();
            }
            return View(tbl_master);
        }
         [Authorize(Roles = "Manager")]
        // GET: /Master/Create
        public ActionResult Create()
        {
            ViewBag.person_id = new SelectList(db.tbl_login, "userid", "username");
            return View();
        }

        // POST: /Master/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
         [Authorize(Roles = "Manager")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="id,Name,Domain,Reportingperson,person_id")] tbl_master tbl_master)
        {
            if (ModelState.IsValid)
            {
                db.tbl_master.Add(tbl_master);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.person_id = new SelectList(db.tbl_login, "userid", "username", tbl_master.person_id);
            return View(tbl_master);
        }
         [Authorize(Roles = "Manager")]
        // GET: /Master/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_master tbl_master = db.tbl_master.Find(id);
            if (tbl_master == null)
            {
                return HttpNotFound();
            }
            ViewBag.person_id = new SelectList(db.tbl_login, "userid", "username", tbl_master.person_id);
            return View(tbl_master);
        }

        // POST: /Master/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
         [Authorize(Roles = "Manager")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Manager")]
        public ActionResult Edit([Bind(Include="id,Name,Domain,Reportingperson,person_id")] tbl_master tbl_master)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tbl_master).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.person_id = new SelectList(db.tbl_login, "userid", "username", tbl_master.person_id);
            return View(tbl_master);
        }

        // GET: /Master/Delete/5
         [Authorize(Roles = "Manager")]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_master tbl_master = db.tbl_master.Find(id);
            if (tbl_master == null)
            {
                return HttpNotFound();
            }
            return View(tbl_master);
        }

        // POST: /Master/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Manager")]
        public ActionResult DeleteConfirmed(int id)
        {
            tbl_master tbl_master = db.tbl_master.Find(id);
            db.tbl_master.Remove(tbl_master);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
