
use db_example

select * from tbl_studlist

create trigger trg_example on tbl_studlist after insert
as
begin
print 'New student joined'
end

insert tbl_studlist values(12,'aaa','ECE',96,'jeppiar')