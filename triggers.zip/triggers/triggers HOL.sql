

-------------TRIGGERS----------------

use db_Rahul


------------------1.If a record is inserted/updated/deleted in the flight booking table, the 
                     RemainingSeats column in the Flight Seat Status must be suitablyupdated.

					select * from tbl_Flight_Booking

					 select * from tbl_FlightSeat_Status

					 create trigger trig_update_seats_abik on tbl_Flight_Booking after insert,update,delete
					 as
					 begin
					 select * from inserted
					 select * from deleted
					 
					 end

					 insert tbl_Flight_Booking values(178,504,4,'2017-05-05','2017-05-07',2,2)

					 delete from tbl_Flight_Booking where BookingID=2223

					 update tbl_Flight_Booking set NoOFAdults=2,NoOfChildren=1 where BookingID=166

					 update tbl_Flight_Booking set NoOFAdults=11,NoOfChildren=13 where FlightNo=506

				

-------------------2.When a record is inserted into the payment table, if the DiscountAvailable column is 1, 
					insert a record into tbl_customer_discounts table.

									select * from tbl_Vehicle_Payment_New

									select * from tbl_Customer_Discounts


					create trigger trig_update_customer_discounts_abiiikanda on tbl_Vehicle_Payment after insert
					as
					begin
					declare @DiscountAvailable int
					
					if(@DiscountAvailable=1)
					print 'record inserted'
					end
					


					 insert tbl_Vehicle_Payment_New values('Pay2',201,160,13.20,1)

					 insert tbl_Customer_Discounts values(217,2,'2016-04-04')



------------------3.When a record is inserted into the payment table, if the DiscountAvailed column is 1, 
					insert a record into tbl_customer_hotel_discounts table.

				
				             	select * from tbl_Hotel_Payment

								select * from tbl_Customer_Hotel_Discounts	


					create trigger trig_update_customer_discounts_abik on tbl_Hotel_Payment after insert
					as
					begin
					declare @DiscountAvailed int
					insert tbl_Hotel_Payment values(6006,600,1000,13050,1)
					if(@DiscountAvailed=1)
					print 'Discount availed'
					end

					
