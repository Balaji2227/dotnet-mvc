﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4AdoPractice
{

    public class  Insertdata
    {
        Icategory iobj;

        public Insertdata (Icategory iobj )
        {
            this.iobj = iobj;
        }
        public void InsertCategoryDetails ()
        {

            string CategoryName;
            string CategoryDescription;

            Console.WriteLine("Enter the CategoryName :");
            CategoryName = Console.ReadLine();
            Console.WriteLine("Enter the Description :");
            CategoryDescription = Console.ReadLine();

            iobj.CategoryDetails(CategoryName, CategoryDescription);

        }
    }



    class Program
    { 
        static void Main(string[] args)
        {
            Icategory catobj = new Category_DAl();
            Insertdata catobj2 = new Insertdata(catobj);
            catobj2.InsertCategoryDetails();

            Console.ReadLine();

        }
    }
}
