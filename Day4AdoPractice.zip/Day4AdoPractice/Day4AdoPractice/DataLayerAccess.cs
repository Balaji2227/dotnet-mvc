﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;

namespace Day4AdoPractice
{
    public interface Icategory
    {
        void CategoryDetails(string Categoryname, string CategoryDescription);
    }

    public class Category_DAl : Icategory
    {
        public void CategoryDetails(string Categoryname, string CategoryDescription)
        {
            
            string connStr = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;

            using(SqlConnection con =  new SqlConnection(connStr))
            {
                //string query = "Insert into Tbl_Category (CategoryName,CategoryDescription) values (@catName,@catDescription)";
                con.Open();
                string  query = "Insert into Tbl_Category values ('"+Categoryname+"','"+CategoryDescription+"')";
                string query1 = "select * from Tbl_Category";
                using(SqlCommand sqlcmd = new SqlCommand(query,con))
                {

                    sqlcmd.ExecuteNonQuery();

                }

                using (SqlCommand cmd1=new SqlCommand(query1,con))
                {
                   
                    SqlDataReader dr = cmd1.ExecuteReader();
                    
                    while (dr.Read())
                    {
                        Console.WriteLine("{0}\t{1}",dr.GetString(0),dr.GetString(1));
                    }
                }

            }
        }
    }
}
