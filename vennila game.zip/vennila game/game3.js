
$(document).ready(function(){
alert("save the man");
alert("Click Question Button To Move To Next Question");
alert("chances For The Player Is Three Times");
alert("double click the bomb button to defuse")
 
    
  $("#b1").click(CountFun);
  $("#b2").click(btn2);
  $("#b3").click(btn3);
  $("#b4").click(btn4);
  $("#b5").click(btn5);
  $("#b6").click(btn6);
  $("#b7").click(btn7);
  $("#b8").click(btn8);
  $("#b9").click(btn9);
  $("#b10").click(btn10);
  $("#b11").click(btn11);
  $("#b12").click(btn12);
  $("#b13").click(btn13);
    

  });
 var arrayQ =[
            ["2*3", "6*1", "2*5","4*4","4*5","10*4","8*2","7*5","8*8","2*15","6*2","1*9","4*23","6*1"],
            ["2*5", "7*1", "1*10","8*4","5*5","1*4","80*2","71*5","8*7","2*1","5*22","1*90","4*3","1*10"],
            ["4*3", "4*1", "8*5","6*2","4*8","10*7","8*2","7*15","8*5","12*15","60*2","11*9","4*23","6*2"],
           ["5*6", "6*18", "2*95","4*4","2*15","5*4","2*2","9*5","6*8","2*1","6*12","1*1","4*3","2*15"],
           ["8*2", "6*8", "2*9","5*4","23*5","4*4","80*2","71*5","8*9","2*5","6*5","1*8","7*23","4*4"],
           ["2*4", "6*9", "2*3","4*8","4*15","1*4","1*8","17*5","9*5","2*5","16*2","3*9","4*3","1*8"],
           ["4*5", "6*11", "2*7","4*44","4*8","1*4","5*2","20*1","0*8","2*15","5*2","9*9","8*3","20*1"],
           ["10*4", "4*1", "2*5","4*4","4*5","10*4","8*2","7*5","20*2","2*15","6*2","1*9","4*23","20*2"],
           ["1*92", "6*11", "2*15","4*8","4*51","1*4","8*1","8*3","8*5","4*23","5*8","1*5","40*2","4*23"],
           ["8*8", "8*1", "12*5","8*4","4*9","10*5","18*2","7*5","8*8","2*15","32*2","1*9","4*23","32*2"],
           ["7*5", "6*1", "2*5","4*4","4*5","10*4","8*2","7*5","8*8","2*15","6*2","35*1","4*3","35*1"],
           ["9*9", "6*1", "2*5","4*4","4*5","10*4","8*2","7*5","8*8","2*15","6*2","1*9","27*3","27*3"],
          
           
        ];
          var disapper;
          
     
       function CountFun(){
         
         if(($("#s1").val()!=11))
          {
           
        var counter = $('#s1').val();
        counter++;
          
         $('#s1').val(counter);
        var value=$('#s1').val();
        $("#b1").val(arrayQ[value][0]);
        $("#b2").val(arrayQ[value][1]);
        $("#b3").val(arrayQ[value][2]);
        $("#b4").val(arrayQ[value][3]);
        $("#b5").val(arrayQ[value][4]);
        $("#b6").val(arrayQ[value][5]);
        $("#b7").val(arrayQ[value][6]);
        $("#b8").val(arrayQ[value][7]);
        $("#b9").val(arrayQ[value][8]);
        $("#b10").val(arrayQ[value][9]);
        $("#b11").val(arrayQ[value][10]);
        $("#b12").val(arrayQ[value][11]);
        $("#b13").val(arrayQ[value][12]);}
        else
           
          {

            if(disapper==12)
              {
               alert(" HOORAY you saved the Man!!!!!!!!!!");
              }
              else{
                alert("still bomb is left");
              }
            
          }

      }
     function btn2()
    {
     if(($("#s2").val()!=4))
        {
        var value=$('#s1').val();
          if(($("#b2").val()===arrayQ[value][13]))
            {
          $("#b2").on("click", function() {
          $("#b2").hide();
          $("#hide2").hide();
           disapper = $("#d3").val();
           disapper++ ;
           $('#d3').val(disapper);
           });
           
           }
         else 
         {
           var chance = $("#s2").attr(value);
           alert(chance);
           chance++ ;
           $('#s2').val(chance);
          }
        }
        else{
          alert("OOPS You Missed The Chance To Save The Man ");
          
        }
          
    } 
      
   function btn3()
   {
   if(($("#s2").val()!=4))
        {
        var value=$('#s1').val();
          if(($("#b3").val()===arrayQ[value][13]))
             {
          
          $("#b3").on("click", function() {
          $("#b3").hide();
          $("#hide3").hide();
           disapper = $("#d3").val();
           disapper++ ;
           $('#d3').val(disapper);
           });
             }
          else 
         {
           var chance = $('#s2').val();
           chance++ ;
            $('#s2').val(chance);
          }
             }
        else{
        alert("OOPS You Missed The Chance To Save The Man ");
        
        }
    } 
  function btn4()
    {
    if(($("#s2").val()!=4))
        {
        var value=$('#s1').val();
        if(($("#b4").val()===arrayQ[value][13]))
             {
              $("#b4").on("click", function() {
              $("#b4").hide();
              $("#hide4").hide();
               disapper = $("#d3").val();
               disapper++ ;
               $('#d3').val(disapper);
           });
      }
     else 
      {
        var chance = $('#s2').val();
        chance++ ;
        $('#s2').val(chance);
      }
         }
        else{
          alert("OOPS You Missed The Chance To Save The Man ");
          
        }
    } 
    function btn5()
    {
    if(($("#s2").val()!=4))
        {
        var value=$('#s1').val();
     if(($("#b5").val()===arrayQ[value][13]))
             {
              $("#b5").on("click", function() {
              $("#b5").hide();
              $("#hide5").hide();
               disapper = $("#d3").val();
               disapper++ ;
               $('#d3').val(disapper);
           });
      }
     else 
      {
         var chance = $('#s2').val();
         chance++ ;
          $('#s2').val(chance);
     }
           }
        else{
          alert("OOPS You Missed The Chance To Save The Man ");
        }
    } 
    function btn6()
    {
      if(($("#s2").val()!=4))
        {
        var value=$('#s1').val();
          
       if(($("#b6").val()===arrayQ[value][13]))
             {
              $("#b6").on("click", function() {
              $("#b6").hide();
              $("#hide6").hide();
               disapper = $("#d3").val();
               disapper++ ;
               $('#d3').val(disapper);
                });
             }
             else 
            {
           var chance = $('#s2').val();
            chance++ ;
             $('#s2').val(chance);
              }
         }
        else{
        alert("OOPS You Missed The Chance To Save The Man ");
        }
    } 
    function btn7()
    {
     if(($("#s2").val()!=4))
        {
       var value=$('#s1').val();
      if(($("#b7").val()===arrayQ[value][13]))
             {
              $("#b7").on("click", function() {
              $("#b7").hide();
              $("#hide7").hide();
               disapper = $("#d3").val();
               disapper++ ;
               $('#d3').val(disapper);
           });
             }
     else 
      {
            var chance = $('#s2').val();
            chance++ ;
             $('#s2').val(chance);
     }
               }
        else{
          alert("OOPS You Missed The Chance To Save The Man ");
         
        }
    } 
    function btn8()
    {
      if(($("#s2").val()!=4))
        {
        var value=$('#s1').val();
          if(($("#b8").val()===arrayQ[value][13]))
             {
              $("#b8").on("click", function() {
              $("#b8").hide();
              $("#hide8").hide();
               disapper = $("#d3").val();
               disapper++ ;
               $('#d3').val(disapper);
           });
            }
     else 
           {
            var chance = $('#s2').val();
            chance++ ;
             $('#s2').val(chance);
            }
               }
        else{
        alert("OOPS You Missed The Chance To Save The Man ");
          
        }
    } 
    function btn9()
    {
      if(($("#s2").val()!=4))
        {
        var value=$('#s1').val();
        if(($("#b9").val()===arrayQ[value][13]))
             {
              $("#b9").on("click", function() {
              $("#b9").hide();
              $("#hide9").hide();
               disapper = $("#d3").val();
               disapper++ ;
               $('#d3').val(disapper);
           });
        }
    else 
         {
           var chance = $('#s2').val();
            chance++ ;
             $('#s2').val(chance);
         }
               }
        else{
          alert("OOPS You Missed The Chance To Save The Man ");
        }
    } 
    function btn10()
    {
    if(($("#s2").val()!=4))
        {
        var value=$('#s1').val();
      if(($("#b10").val()===arrayQ[value][13]))
             {
              $("#b10").on("click", function() {
              $("#b10").hide();
              $("#hide10").hide();
               disapper = $("#d3").val();
               disapper++ ;
               $('#d3').val(disapper);
           });
      }
     else 
      {
            var chance = $('#s2').val();
            chance++ ;
            $('#s2').val(chance);
     }
             }
        else{
         alert("OOPS You Missed The Chance To Save The Man ");
         
        }
    } 
    function btn11()
    {
     if(($("#s2").val()!=4))
        {
        var value=$('#s1').val();
        if(($("#b11").val()===arrayQ[value][13]))
             {
              $("#b11").on("click", function() {
              $("#b11").hide();
              $("#hide11").hide();
               disapper = $("#d3").val();
               disapper++ ;
               $('#d3').val(disapper);
           });
         }
     else 
         {
            var chance = $('#s2').val();
            chance++ ;
             $('#s2').val(chance);
          }
               }
        else{
          alert("OOPS You Missed The Chance To Save The Man ");
         
        }
    } 
     function btn12()
    {
     if(($("#s2").val()!=4))
        {
        var value=$('#s1').val();
        if(($("#b12").val()===arrayQ[value][13]))
             {
              $("#b12").on("click", function() {
              $("#b12").hide();
              $("#hide12").hide();
               disapper = $("#d3").val();
               disapper++ ;
               $('#d3').val(disapper);
           });
         }
     else 
         {
            var chance = $('#s2').val();
            chance++ ;
             $('#s2').val(chance);
          }
               }
        else{
          alert("OOPS You Missed The Chance To Save The Man ");
         
        }
    } 
    function btn13()
    {
     if(($("#s2").val()!=4))
        {
        var value=$('#s1').val();
        if(($("#b13").val()===arrayQ[value][13]))
             {
              $("#b13").on("click", function() {
              $("#b13").hide();
              $("#hide13").hide();
               disapper = $("#d3").val();
               disapper++ ;
               $('#d3').val(disapper);
           });
         }
     else 
         {
            var chance = $('#s2').val();
            chance++ ;
             $('#s2').val(chance);
          }
               }
        else{
          alert("OOPS You Missed The Chance To Save The Man ");
         
        }
    } 
    