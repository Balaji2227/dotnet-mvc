﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EntityFrameworkJqGrid;
using System.Data.Entity;

namespace EntityFrameworkJqGrid.Controllers
{
    public class JqgridExampleController : Controller
    {
        //
        // GET: /JqgridExample/
        public ActionResult Index()
        {
            return View();
        }
        Aravind_traineeEntities db = new Aravind_traineeEntities();

        public JsonResult GetValues(string sord,int page,int rows)  
        {
            int pageIndex = Convert.ToInt32(page) - 1;
            int pageSize = rows;
            var Results = db.Tbl_Employees.Select(
                a => new
                {
                    a.EmpId,
                    a.EmpName,
                    a.EmpGender,
                    a.EmoDob,
                    
                });
                
            int totalRecords = Results.Count();
            var totalPages = (int)Math.Ceiling((float)totalRecords / (float)rows);
            if (sord.ToUpper() == "DESC")
            {
                Results = Results.OrderByDescending(s => s.EmpId);
                Results = Results.Skip(pageIndex * pageSize).Take(pageSize);
            }
            else
            {
                Results = Results.OrderBy(s => s.EmpId);
                Results = Results.Skip(pageIndex * pageSize).Take(pageSize);
            }
            var jdata = new
            {
                total = totalPages,
                page=page,
                records = totalRecords,
                rows = Results
            };
            return  Json(jdata, JsonRequestBehavior.AllowGet);
        }



        [HttpPost]
        public string Create(Tbl_Employees obj)
        {
            string msg;
            try
            {
                if (ModelState.IsValid)
                {
                    db.Tbl_Employees.Add(obj);
                    db.SaveChanges();
                    msg = "Saved Successfully";
                }
                else
                {
                    msg = "Validation data not successfull";
                }
            }
            catch (Exception ex)
            {
                msg = "Error occured:" + ex.Message;
            }
            return msg;
        }

        public string Edit(Tbl_Employees obj)
        {
            string msg;
            try
            {
                if (ModelState.IsValid)
                {
                    db.Entry(obj).State = EntityState.Modified;
                    db.SaveChanges();
                    msg = "Saved Successfully";
                }
                else
                {
                    msg = "Validation data not successfull";
                }
            }
            catch (Exception ex)
            {
                msg = "Error occured:" + ex.Message;
            }
            return msg;
        }
        public string Delete(int EmpId)
        {
            Tbl_Employees list = db.Tbl_Employees.Find(EmpId);
            db.Tbl_Employees.Remove(list);
            db.SaveChanges();
            return "Deleted successfully";
        }  
    }  
}  

  
  