﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace sample1
{
    public partial class register_page : System.Web.UI.Page
    {
        Iregister iobj;

        public register_page (Iregister iobj)
        {
            this.iobj = iobj;
        }


        //protected void page_load(object sender, eventargs e)
        //{

        //}

        public void save_Click()
        {

            string username=txtName.Text;
            int mobile=Convert.ToInt32 (txtMobile.Text);
            string useremail = txtEmail.Text;
            string userpassword = txtpassword.Text;


            iobj.employee_details(username,mobile,useremail,userpassword);


            Response.Write("<Script>alert ('data saved successfully');</Script>");
        }
            public void save_Click(object sender, EventArgs e)
           {

           }
    }
    class program
    {
        static void Main(string[] args)
        {
            Iregister obj1 = new register_DAL();
            register_page obj2 = new register_page(obj1);
            obj2.save_Click();
        }


    }
       
   

           // register_DAL obj = new register_DAL();
           // obj.employee_details(username,mobile,useremail,userpassword);
          
            
        

        
    }
