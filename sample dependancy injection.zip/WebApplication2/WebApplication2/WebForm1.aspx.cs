﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
         Iregister iobj;

         public WebForm1(Iregister iobj)
        {
            this.iobj = iobj;
        }
        protected void Page_Load(object sender, EventArgs e)
        {

        }



      
       

        protected void Button1_Click()
        {
            string useremail = TextBox1.Text;
            string userpassword = TextBox2.Text;

            iobj.employee_details(useremail, userpassword);


            Response.Write("<Script>alert ('data saved successfully');</Script>");
        }
        class program
        {
            static void Main(string[] args)
            {
                Iregister obj1 = new Class1();
                WebForm1 obj2 = new WebForm1(obj1);
                obj2.Button1_Click();
            }

        }

        
    }
}