﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;

namespace WebApplication2
{
    public interface Iregister
    {
        void employee_details(string useremail, string userpassword);
    }
    public class Class1 : Iregister
    {
       public void employee_details(string useremail, string userpassword)
        {
            try
            {

                string connStr = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;

                using (SqlConnection Con = new SqlConnection(connStr))
                {
                    String query = "INSERT INTO test (useremail,userpassword) VALUES (@TextBox1,@TextBox2)";
                    using (SqlCommand cmd = new SqlCommand(query, Con))
                    {
                        Con.Open();

                        cmd.Parameters.AddWithValue("@TextBox1", useremail);
                        cmd.Parameters.AddWithValue("@TextBox2", userpassword);
                        cmd.ExecuteNonQuery();
                        Con.Close();
                    }

                   
                }

            }
            catch (Exception exc)
            {
                Console.Write(exc);
            }

        
        }
    }
}